rand_vector = [-1]*8
z_0 = [3]
# print(rand_vector)
for a in range(8):
  G1_z = (12*z_0[-1] + 7)%11
  z_0.append(G1_z)
  rand_vector[a] = G1_z
# print(rand_vector)

z_1 = [5]
for a in range(4):
  G2_z = (9*z_1[-1] + 3)%8
  z_1.append(G2_z)
  G1_z = (12*z_0[-1] + 7)%11
  z_0.append(G1_z)
  rand_vector[G2_z] = G1_z

print(rand_vector)